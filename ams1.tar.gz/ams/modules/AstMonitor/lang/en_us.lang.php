<?php
$strAstMonitor='Asterisk Channels & Events Monitor';
?>