<?php
$strSave='Save';
$strPrint='Print';
$strUndo='Undo';
$strRedo='Redo';
$strReplace='Replace';
$strFind='Find';
$strCut='Cut';
$strCopy='Copy';
$strPaste='Paste';
$strSelectAll='Select All';
$strFileSaved='File saved...';
$strCantOpenFile='Can\'t open file';
$strCantWriteFile='Can\'t write file';
$strWrongFile='File not exists';
$strReadFile='Read file';
?>