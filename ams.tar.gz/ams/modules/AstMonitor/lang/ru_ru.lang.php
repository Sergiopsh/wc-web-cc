<?php
$strAstMonitor='Астериск Монитор';
?>