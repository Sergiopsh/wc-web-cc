<?php
$strSave='Сохранить';
$strPrint='Печать';
$strUndo='Отменить';
$strRedo='Вернуть';
$strReplace='Заменить';
$strFind='Найти';
$strCut='Вырезать';
$strCopy='Копировать';
$strPaste='Вставить';
$strSelectAll='Выбрать все';
$strFileSaved='Файл сохранен...';
$strCantOpenFile='Не могу открыть файл';
$strCantWriteFile='Не могу записать файл';
$strWrongFile='Файл не существует';
$strReadFile='Прочитать файл';
?>