<?php
//Departments
$strDepartment='Отдел';
$strEmployee='Сотрудник';
$strDepartments='Отделы';
$strDepartmentsList='Список отделов';
$strDepartmentName='Название';
$strAddDepartment='Добавить отдел';
$strEditDepartment='Редактировать отдел';
$strDeleteDepartment='Удалить отдел';
$strDeleteSelected='Удалить выбранные отделы';
$strViewEmployees='Список сотрудников отдела';
$strNameDep='Название';
$strChief='Руководитель';
$strTel='Тел.(любой)';
$strEmail='E-mail';
$strPhoneWork='Раб. тел.';
$strPhoneOffice='Внутр. тел.';
$strNoDeps='Нет отделов';
$strExportCSV='Экспорт в CSV';
$strStatus='Статус';
$strActive='Активный';
$strDisabled='Неакитвный';
$strDesc='Описание';
$strDepartmentSaveSuccess='Информация сохранена...';
$strWinConfirmDeleteDep='Подтверждаете удаление отдела';
$strShortNameDep='Кор. назв.';
$strFax='Факс';
$strDepartmentExists='Отдел существует, проверьте, пожалуйста...';
$strWinConfirmDeleteSelected='Подтверждаете удаление выбранных отделов';
?>